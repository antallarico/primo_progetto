<?php

use Illuminate\Support\Facades\Route;
use App\Models\Lavoratore;
use App\Http\Controllers\Formazione\FormazioneCorsoController;
use App\Http\Controllers\Formazione\SessioneController;
use App\Http\Controllers\Formazione\FormazioneController;
use App\Http\Controllers\Formazione\StoricoLavoratoreController;
use App\Http\Controllers\Formazione\LavoratoriReportController;
use App\Http\Controllers\LavoratoreController;
use App\Http\Controllers\AttrezzaturaController;
use App\Http\Controllers\AttrezzaturaEstintoreController;
use App\Http\Controllers\SchedaAttrezzaturaController;
use App\Http\Controllers\AttrezzaturaTipologiaController;
use App\Http\Controllers\AttrezzaturaGruController;
use App\Http\Controllers\Attrezzature\SchedaGenericaController;
use App\Http\Controllers\Attrezzature\SchedaDinamicaController;
use App\Http\Controllers\Attrezzature\SchedaVoceController;
use App\Http\Controllers\Manutenzioni\TipologiaController;
//use App\Http\Controllers\Manutenzioni\ChecklistController;
use App\Http\Controllers\ModelliDinamici\ModelloDinamicoController;
use App\Http\Controllers\Manutenzioni\RegistroController;



// --- Modelli dinamici (CRUD + JSON + Builder) ------------------------------
Route::prefix('modelli-dinamici')->name('modelli_dinamici.')->group(function () {
    Route::get('/',                     [ModelloDinamicoController::class, 'index'])->name('index');
    Route::get('/create',               [ModelloDinamicoController::class, 'create'])->name('create');
    Route::post('/',                    [ModelloDinamicoController::class, 'store'])->name('store');
    Route::get('/{modelloDinamico}/edit',[ModelloDinamicoController::class, 'edit'])->name('edit');
    Route::put('/{modelloDinamico}',    [ModelloDinamicoController::class, 'update'])->name('update');
    Route::delete('/{modelloDinamico}', [ModelloDinamicoController::class, 'destroy'])->name('destroy');

    // builder pagina dedicata (se usata)
    Route::get('/{id}/builder',         [ModelloDinamicoController::class, 'builder'])->name('builder');
});

// endpoint JSON v2 (schema+layout) usato dal mount-by-select
Route::get('/modelli-dinamici/{id}/json', [ModelloDinamicoController::class, 'showJson'])
    ->name('modelli_dinamici.json');

// --- Registro (le tue rotte già esistenti qui) ------------------------------
// ...lascia invariato il resto (index/create/store/edit/update/destroy del Registro)


/*
Route::prefix('modelli-dinamici')->name('modelli_dinamici.')->group(function () {
    Route::get('/',                           [ModelloDinamicoController::class, 'index'])->name('index');
    Route::get('/create',                     [ModelloDinamicoController::class, 'create'])->name('create');
    Route::post('/',                          [ModelloDinamicoController::class, 'store'])->name('store');
    Route::get('/{modelloDinamico}/edit',     [ModelloDinamicoController::class, 'edit'])->name('edit');
    Route::put('/{modelloDinamico}',          [ModelloDinamicoController::class, 'update'])->name('update');
    Route::delete('/{modelloDinamico}',       [ModelloDinamicoController::class, 'destroy'])->name('destroy');

	// endpoint JSON “nuovo” usato dal wrapper (ID numerico)
	Route::get('/{id}/json',                  [ModelloDinamicoController::class, 'showJson'])->name('json');
	// endpoint "campi" legacy (se il metodo esiste e serve ancora)
    Route::get('/{id}/campi',                 [ModelloDinamicoController::class, 'campiJson'])->name('campi');

    // builder
    Route::get('/{id}/builder',               [ModelloDinamicoController::class, 'builder'])->name('builder');

    // endpoint JSON campi (compatibilità con integrazione esistente)
    //Route::get('/{modelloDinamico}/campi',    [ModelloDinamicoController::class, 'campiJson'])->name('campi');
});
*/


Route::get('/lavoratori', function () {
    $lavoratori = Lavoratore::orderBy('cognome')->orderBy('nome')->get();
    return view('lavoratori.index', compact('lavoratori'));
});


// Formazione-corsi
Route::prefix('formazione/corsi')->name('formazione.corsi.')->group(function () {
    Route::get('/', [FormazioneCorsoController::class, 'index'])->name('index');
    Route::get('/create', [FormazioneCorsoController::class, 'create'])->name('create');
    Route::post('/', [FormazioneCorsoController::class, 'store'])->name('store');
    Route::get('/{corso}/edit', [FormazioneCorsoController::class, 'edit'])->name('edit');
    Route::put('/{corso}', [FormazioneCorsoController::class, 'update'])->name('update');
    Route::delete('/{corso}', [FormazioneCorsoController::class, 'destroy'])->name('destroy');
});
// Formazione-sessioni (eventi/lezioni/corsi/attività formative svolte)
Route::prefix('formazione/sessioni')->name('formazione.sessioni.')->group(function () {
    Route::get('/', [SessioneController::class, 'index'])->name('index');
    Route::get('/create', [SessioneController::class, 'create'])->name('create');
    Route::post('/', [SessioneController::class, 'store'])->name('store');
    Route::get('/{sessione}/edit', [SessioneController::class, 'edit'])->name('edit');
    Route::put('/{sessione}', [SessioneController::class, 'update'])->name('update');
    Route::delete('/{sessione}', [SessioneController::class, 'destroy'])->name('destroy');
});
// Formazione Registro partecipazioni alle sessioni
Route::prefix('formazione/registro')->name('formazione.registro.')->group(function () {
    Route::get('/{sessione_id}', [\App\Http\Controllers\Formazione\FormazioneController::class, 'index'])->name('index');
    Route::get('/{sessione_id}/create', [\App\Http\Controllers\Formazione\FormazioneController::class, 'create'])->name('create');
    Route::post('/{sessione_id}', [\App\Http\Controllers\Formazione\FormazioneController::class, 'store'])->name('store');
    Route::get('/partecipazione/{id}/edit', [\App\Http\Controllers\Formazione\FormazioneController::class, 'edit'])->name('edit');
    Route::put('/partecipazione/{id}', [\App\Http\Controllers\Formazione\FormazioneController::class, 'update'])->name('update');
    Route::delete('/partecipazione/{id}', [\App\Http\Controllers\Formazione\FormazioneController::class, 'destroy'])->name('destroy');
});

// Storico formazione del lavoratore
Route::get('/formazione/storicolavoratore/{lavoratore}', [\App\Http\Controllers\Formazione\FormazioneController::class, 'storicolavoratore'])
    ->name('formazione.storicolavoratore');

// Elenco lavoratori per Storico formazione
Route::get('/formazione/lavoratori', [FormazioneController::class, 'lavoratori'])->name('formazione.lavoratori');
// Storico formazione per corso
//Route::get('/formazione/storicocorso/{corso}', [FormazioneController::class, 'storicocorso'])->name('formazione.storicocorso');
Route::get('/formazione/storicocorso/{corso_id}', [FormazioneController::class, 'storicocorso'])->name('formazione.storicocorso');


// Attrezzature
Route::get('/attrezzature', [AttrezzaturaController::class, 'index'])->name('attrezzature.index');
Route::get('/attrezzature/create', [AttrezzaturaController::class, 'create'])->name('attrezzature.create');
Route::post('/attrezzature', [AttrezzaturaController::class, 'store'])->name('attrezzature.store');
Route::get('/attrezzature/{attrezzatura}/edit', [AttrezzaturaController::class, 'edit'])->name('attrezzature.edit');
Route::put('/attrezzature/{attrezzatura}', [AttrezzaturaController::class, 'update'])->name('attrezzature.update');
Route::delete('/attrezzature/{attrezzatura}', [AttrezzaturaController::class, 'destroy'])->name('attrezzature.destroy');


// CRUD tipologie attrezzature
Route::prefix('attrezzature/tipologie')
    ->name('attrezzature.tipologie.')
    ->group(function () {
        Route::get('/', [AttrezzaturaTipologiaController::class, 'index'])->name('index');
        Route::get('/create', [AttrezzaturaTipologiaController::class, 'create'])->name('create');
        Route::post('/', [AttrezzaturaTipologiaController::class, 'store'])->name('store');
        Route::get('/{tipologia}/edit', [AttrezzaturaTipologiaController::class, 'edit'])->name('edit');
        Route::put('/{tipologia}', [AttrezzaturaTipologiaController::class, 'update'])->name('update');
        Route::delete('/{tipologia}', [AttrezzaturaTipologiaController::class, 'destroy'])->name('destroy');
    });

// Gestione Schede dinamiche Attrezzature da modelli_dinamici
//Route::get('attrezzature/schede/create/{attrezzatura}/{modello}', [SchedaVoceController::class, 'create'])->name('attrezzature.schede_voci.create');
Route::prefix('attrezzature/schede/{attrezzatura}/voci/{modello}')->name('attrezzature.schede_voci.')->group(function () {
    Route::get('/create', [SchedaVoceController::class, 'create'])->name('create');
    Route::post('/', [SchedaVoceController::class, 'store'])->name('store');
    Route::get('/edit', [SchedaVoceController::class, 'edit'])->name('edit');
    Route::put('/', [SchedaVoceController::class, 'update'])->name('update');
    Route::get('/', [SchedaVoceController::class, 'show'])->name('show'); // opzionale
});


// Gestione Schede dinamiche Attrezzature
Route::get('/attrezzature/scheda/{id}/campi', [App\Http\Controllers\Attrezzature\SchedaDinamicaController::class, 'campi']);
Route::resource('attrezzature/schede', SchedaDinamicaController::class)->names('attrezzature.schede');
Route::put('attrezzature/schede/{scheda}', [SchedaDinamicaController::class, 'update'])->name('attrezzature.schede.update');
Route::get('attrezzature/schede', [SchedaDinamicaController::class, 'index'])->name('attrezzature.schede.index');
Route::get('attrezzature/schede/create', [SchedaDinamicaController::class, 'create'])->name('attrezzature.schede.create');
Route::post('attrezzature/schede', [SchedaDinamicaController::class, 'store'])->name('attrezzature.schede.store');
Route::get('attrezzature/schede/{scheda}/edit', [SchedaDinamicaController::class, 'edit'])->name('attrezzature.schede.edit');
Route::put('attrezzature/schede/{scheda}', [SchedaDinamicaController::class, 'update'])->name('attrezzature.schede.update');
Route::delete('attrezzature/schede/{scheda}', [SchedaDinamicaController::class, 'destroy'])->name('attrezzature.schede.destroy');

// Gestione Schede dinamiche Attrezzature Voci 
Route::prefix('attrezzature/schede')->name('attrezzature.schede_')->group(function () {
    Route::get('{attrezzatura}/voci', [SchedaVoceController::class, 'index'])->name('voci.index');
 ;

Route::get('schede/{scheda}/voci/create', [SchedaVoceController::class, 'create'])->name('attrezzature.schede_voci.create');
    Route::post('{attrezzatura}/voci', [SchedaVoceController::class, 'store'])->name('voci.store');
    Route::get('{attrezzatura}/voci/{voce}/edit', [SchedaVoceController::class, 'edit'])->name('voci.edit');
    Route::put('{attrezzatura}/voci/{voce}', [SchedaVoceController::class, 'update'])->name('voci.update');
    Route::delete('{attrezzatura}/voci/{voce}', [SchedaVoceController::class, 'destroy'])->name('voci.destroy');
});
Route::get('/attrezzature/schede/{attrezzatura}/voci/create', [SchedaVoceController::class, 'create'])->name('attrezzature.schede_voci.create');


// Gestione schede estintori collegate alle attrezzature
Route::get('/attrezzature/{attrezzatura}/estintore/create', [AttrezzaturaEstintoreController::class, 'create'])->name('attrezzature.estintore.create');
Route::post('/attrezzature/{attrezzatura}/estintore', [AttrezzaturaEstintoreController::class, 'store'])->name('attrezzature.estintore.store');
Route::get('/attrezzature/{attrezzatura}/estintore/edit', [AttrezzaturaEstintoreController::class, 'edit'])->name('attrezzature.estintore.edit');
Route::put('/attrezzature/{attrezzatura}/estintore', [AttrezzaturaEstintoreController::class, 'update'])->name('attrezzature.estintore.update');
Route::delete('/attrezzature/{attrezzatura}/estintore', [AttrezzaturaEstintoreController::class, 'destroy'])->name('attrezzature.estintore.destroy');

// Gestione schede gru collegate alle attrezzature
Route::get('/attrezzature/{attrezzatura}/gru/create', [AttrezzaturaGruController::class, 'create'])->name('attrezzature.gru.create');
Route::post('/attrezzature/{attrezzatura}/gru', [AttrezzaturaGruController::class, 'store'])->name('attrezzature.gru.store');
Route::get('/attrezzature/{attrezzatura}/gru/edit', [AttrezzaturaGruController::class, 'edit'])->name('attrezzature.gru.edit');
Route::put('/attrezzature/{attrezzatura}/gru', [AttrezzaturaGruController::class, 'update'])->name('attrezzature.gru.update');
Route::delete('/attrezzature/{attrezzatura}/gru', [AttrezzaturaGruController::class, 'destroy'])->name('attrezzature.gru.destroy');


// Gestione schede collegate alle attrezzature
Route::get('/attrezzature/{attrezzatura}/scheda/create', [SchedaAttrezzaturaController::class, 'create'])->name('scheda_attrezzatura.create');
Route::get('/attrezzature/{attrezzatura}/scheda/edit', [SchedaAttrezzaturaController::class, 'edit'])->name('scheda_attrezzatura.edit');

// Gestione schede collegate alle attrezzature con JSON
Route::get('attrezzature/{id}/scheda', [SchedaGenericaController::class, 'edit'])
    ->name('scheda.generica.edit');
Route::patch('attrezzature/{id}/scheda', [SchedaGenericaController::class, 'update'])
    ->name('scheda.generica.update');

// Gestione Manutenzioni	
Route::prefix('manutenzioni')->name('manutenzioni.')->group(function () {
    Route::resource('competenze', \App\Http\Controllers\Manutenzioni\CompetenzaController::class);
});
Route::prefix('manutenzioni')->name('manutenzioni.')->group(function () {
    Route::resource('programmate', \App\Http\Controllers\Manutenzioni\ProgrammataController::class);
});
Route::prefix('manutenzioni')->name('manutenzioni.')->group(function () {
    Route::resource('registro', \App\Http\Controllers\Manutenzioni\RegistroController::class);
});
// Gestione Manutenzioni RegistroVoceController
Route::prefix('manutenzioni/registro/{registro}/voci')->name('manutenzioni.registro-voci.')->group(function () {
    Route::get('create/{modello}', [RegistroVoceController::class, 'create'])->name('create');
    Route::post('{modello}', [RegistroVoceController::class, 'store'])->name('store');
    Route::get('{modello}/edit', [RegistroVoceController::class, 'edit'])->name('edit');
    Route::put('{modello}', [RegistroVoceController::class, 'update'])->name('update');
});
Route::prefix('manutenzioni')->name('manutenzioni.')->group(function () {
    Route::get('registro/{registro}/voci', [\App\Http\Controllers\Manutenzioni\RegistroVoceController::class, 'index'])->name('registro-voci.index');
    Route::get('registro/{registro}/voci/create', [\App\Http\Controllers\Manutenzioni\RegistroVoceController::class, 'create'])->name('registro-voci.create');
    Route::post('registro/{registro}/voci', [\App\Http\Controllers\Manutenzioni\RegistroVoceController::class, 'store'])->name('registro-voci.store');
    Route::get('registro/{registro}/voci/{id}/edit', [\App\Http\Controllers\Manutenzioni\RegistroVoceController::class, 'edit'])->name('registro-voci.edit');
    Route::put('registro/{registro}/voci/{id}', [\App\Http\Controllers\Manutenzioni\RegistroVoceController::class, 'update'])->name('registro-voci.update');
    Route::delete('registro/{registro}/voci/{id}', [\App\Http\Controllers\Manutenzioni\RegistroVoceController::class, 'destroy'])->name('registro-voci.destroy');
});
// Gestione Manutenzioni manutenzioni_tipologie e manutenzioni_checklist_dinamiche
Route::prefix('manutenzioni')->name('manutenzioni.')->group(function () {
    Route::resource('tipologie', TipologiaController::class);
    Route::resource('checklist', ChecklistController::class);
});


// Dashboard iniziale
Route::get('/', function () {
    return view('dashboard');
})->name('dashboard');

