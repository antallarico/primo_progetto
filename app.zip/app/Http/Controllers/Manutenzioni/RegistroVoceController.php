<?php

namespace App\Http\Controllers\Manutenzioni;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ManutenzioneRegistro;
use App\Models\ManutenzioneRegistroVoce;
use App\Models\ModelloDinamico;

class RegistroVoceController extends Controller
{
    public function create($registro_id, $modello_id)
    {
        $registro = ManutenzioneRegistro::findOrFail($registro_id);
        $modello = ModelloDinamico::where('id', $modello_id)
            ->where('modulo', 'Manutenzioni')
            ->firstOrFail();

        $campi = $modello->contenuto; // JSON castato come array nel model
        $valoriPrecaricati = []; // Nessun valore in fase di creazione

        return view('manutenzioni.registro_voci.create', compact('registro', 'modello', 'campi', 'valoriPrecaricati'));
    }

    public function store(Request $request)
    {
        $registro_id = $request->input('registro_id');
        $modello_id = $request->input('modello_id');

        $modello = ModelloDinamico::findOrFail($modello_id);
        $campi = $modello->contenuto;

        if (!is_array($campi)) {
            return back()->with('error', 'Errore nel modello dinamico.');
        }

        $voci = $request->input('voci', []);

        foreach ($voci as $voce) {
            $descrizione = $voce['descrizione'] ?? null;
            //$valore = $voce['valore'] ?? null;
			$valore = array_key_exists('valore', $voce) ? $voce['valore'] : '0';

            if ($descrizione !== null) {
                ManutenzioneRegistroVoce::create([
                    'registro_id' => $registro_id,
                    'modello_id' => $modello_id,
                    'voce' => $descrizione,
                    //'esito_voce' => is_array($valore) ? json_encode($valore) : $valore,
					'esito_voce' => is_array($valore) ? json_encode($valore) : ($valore ?? null),
                    'note' => null,
                ]);
            }
        }

        return redirect()->route('manutenzioni.registro.index')->with('success', 'Scheda registrata con successo.');
    }

    public function edit($registro_id, $modello_id)
    {
        $registro = ManutenzioneRegistro::findOrFail($registro_id);
        $modello = ModelloDinamico::where('id', $modello_id)
            ->where('modulo', 'Manutenzioni')
            ->firstOrFail();

        $voci = ManutenzioneRegistroVoce::where('registro_id', $registro_id)
            ->where('modello_id', $modello_id)
            ->get();

        $valoriPrecaricati = $voci->map(fn($voce) => [
            'voce' => $voce->voce,
            'valore' => $voce->esito_voce,
        ])->toArray();

        $campi = $modello->contenuto;

        return view('manutenzioni.registro_voci.edit', compact('registro', 'modello', 'campi', 'valoriPrecaricati'));
    }

    public function update(Request $request, $registro_id, $modello_id)
    { //dd($request->all());
        $voci = $request->input('voci', []);

        // Elimina voci esistenti
        ManutenzioneRegistroVoce::where('registro_id', $registro_id)
            ->where('modello_id', $modello_id)
            ->delete();

        foreach ($voci as $voce) {
            $descrizione = $voce['descrizione'] ?? null;
            //$valore = $voce['valore'] ?? null;
			$valore = array_key_exists('valore', $voce) ? $voce['valore'] : '0';

            if ($descrizione !== null) {
                ManutenzioneRegistroVoce::create([
                    'registro_id' => $registro_id,
                    'modello_id' => $modello_id,
                    'voce' => $descrizione,
                    //'esito_voce' => is_array($valore) ? json_encode($valore) : $valore,
					'esito_voce' => is_array($valore) ? json_encode($valore) : ($valore ?? null),
                    'note' => null,
                ]);
            }
        }

        return redirect()->route('manutenzioni.registro.index')->with('success', 'Scheda aggiornata con successo.');
    }
}
