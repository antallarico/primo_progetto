<?php

namespace App\Http\Controllers\Manutenzioni;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ManutenzioneRegistro;
use App\Models\ManutenzioneRegistroVoce;
use App\Models\ManutenzioneProgrammata;
use App\Models\ManutenzioneTipologia;
use App\Models\ManutenzioneCompetenza;
use App\Models\Attrezzatura;
use App\Models\ModelloDinamico;

class RegistroController extends Controller
{
    public function index()
    {
        $interventi = ManutenzioneRegistro::with(['attrezzatura', 'tipologia', 'competenza', 'programmata'])->orderBy('data', 'desc')->get();
        return view('manutenzioni.registro.index', compact('interventi'));
    }

    public function create()
    {
        $attrezzature = Attrezzatura::orderBy('nome')->get();
        $tipologie = ManutenzioneTipologia::orderBy('nome')->get();
        $competenze = ManutenzioneCompetenza::orderBy('nome')->get();
        $programmate = ManutenzioneProgrammata::orderBy('id')->get();
		$modelli = ModelloDinamico::where('modulo', 'Manutenzioni')->get();

		return view('manutenzioni.registro.create', compact('attrezzature', 'tipologie', 'competenze', 'programmate', 'modelli'));

    }

    public function store(Request $request)
    {
		\Log::debug('📥 Dati ricevuti dal form:', $request->all());

        $validated = $request->validate([
            'attrezzatura_id' => 'required|exists:attrezzature,id',
            'tipologia_id' => 'nullable|exists:manutenzioni_tipologie,id',
			'modello_id' => 'nullable|exists:modelli_dinamici,id',
            'competenza_id' => 'nullable|exists:manutenzioni_competenze,id',
            'programmata_id' => 'nullable|exists:manutenzioni_programmate,id',
            'data_esecuzione' => 'required|date',
			//'data' => 'required|date',   --- campo previsto per uso futuro
            'esito' => 'nullable|string|max:255',
            'note' => 'nullable|string',
            'voci' => 'nullable|array',
            'voci.*.descrizione' => 'required|string',
            'voci.*.valore' => 'nullable|string', // o boolean per checkbox
        ]);
		

        // Rimuovo voci prima del salvataggio per usare create separatamente
        $voci = $validated['voci'] ?? [];
        unset($validated['voci']);

        $registro = ManutenzioneRegistro::create($validated);
		
		$modello_id = $request->input('modello_id');

		if (!empty($voci) && $modello_id) {
			foreach ($voci as $voce) {
				$registro->voci()->create([
					'registro_id' => $registro->id,
					'modello_id' => $modello_id,
					'voce' => $voce['descrizione'],
					'esito_voce' => $voce['valore'] ?? null,
					'note' => null,
				]);
			}
		}
				
        return redirect()->route('manutenzioni.registro.index')->with('success', 'Intervento registrato con successo');
    }

    public function edit($id)
    {
        $intervento = ManutenzioneRegistro::with('voci')->findOrFail($id);
        $attrezzature = Attrezzatura::orderBy('nome')->get();
        $tipologie = ManutenzioneTipologia::orderBy('nome')->get();
        $competenze = ManutenzioneCompetenza::orderBy('nome')->get();
        $programmate = ManutenzioneProgrammata::orderBy('id')->get();
        //$checklists = ManutenzioneChecklistDinamica::all();
		$modelli = ModelloDinamico::where('modulo', 'Manutenzioni')->get();


        //return view('manutenzioni.registro.edit', compact('intervento', 'attrezzature', 'tipologie', 'competenze', 'programmate', 'checklists'));
		return view('manutenzioni.registro.edit', compact('intervento', 'attrezzature', 'tipologie', 'competenze', 'programmate', 'modelli'));
    }

    public function update(Request $request, $id)
    {

        $intervento = ManutenzioneRegistro::findOrFail($id);

        $validated = $request->validate([
            'attrezzatura_id' => 'required|exists:attrezzature,id',
            'tipologia_id' => 'nullable|exists:manutenzioni_tipologie,id',
			'modello_id' => 'nullable|exists:modelli_dinamici,id',
            'competenza_id' => 'nullable|exists:manutenzioni_competenze,id',
            'programmata_id' => 'nullable|exists:manutenzioni_programmate,id',
            'data_esecuzione' => 'required|date',
            'esito' => 'nullable|string|max:100',
            'note' => 'nullable|string',
            'voci' => 'nullable|array',
            'voci.*.descrizione' => 'required|string',
            'voci.*.valore' => 'nullable|string',
        ]);
//dd($validated);
        //$voci = $validated['voci'] ?? [];
        //unset($validated['voci']);
		
		$voci = $request->input('voci', []);
		
		$modello_id = $request->input('modello_id');

		// Aggiorna il registro (escludi 'voci' se presente)
		$datiRegistro = $validated;
		unset($datiRegistro['voci']);
		
        $intervento->update(array_merge($validated, ['modello_id' => $modello_id]));
		
		$intervento->voci()->delete();
		

		if (!empty($voci) && $modello_id) {
			foreach ($voci as $voce) {
				$intervento->voci()->create([
					'registro_id' => $intervento->id,
					'modello_id' => $modello_id,
					'voce' => $voce['descrizione'],
					'esito_voce' => $voce['valore'] ?? null,
					'note' => null,
				]);
			}
		}
/*		
		if (!empty($voci)) {
            foreach ($voci as $voce) {
                $intervento->voci()->create([
                    'registro_id' => $intervento->id,
                    'voce' => $voce['descrizione'],
                    'esito' => $voce['valore'] ?? null,
                ]);
            }
        } elseif ($intervento->checklist_id) {
            $checklist = ManutenzioneChecklistDinamica::find($intervento->checklist_id);
            if ($checklist && is_array($checklist->contenuto)) {
                foreach ($checklist->contenuto as $campo) {
                    $intervento->voci()->create([
                        'registro_id' => $intervento->id,
                        'voce' => $campo['label'] ?? 'Voce senza nome',
                        'esito' => null,
                        'note' => null,
                    ]);
                }
            }
        }
*/
/*
        // Rigenero voci associate
        $intervento->voci()->delete();
        foreach ($voci as $voce) {
            //ManutenzioneRegistroVoce::create
			$intervento->voci()->create([
                'registro_id' => $intervento->id,
                'voce' => $voce['descrizione'],
                'esito' => $voce['valore'],
            ]);
        }
*/
        return redirect()->route('manutenzioni.registro.index')->with('success', 'Intervento aggiornato');
    }

    public function destroy($id)
    {
        $intervento = ManutenzioneRegistro::findOrFail($id);
        $intervento->delete();

        return redirect()->route('manutenzioni.registro.index')->with('success', 'Intervento eliminato');
    }

    public function show($id)
    {
        return redirect()->route('manutenzioni.registro.edit', $id);
    }
}

