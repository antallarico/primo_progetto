<?php

namespace App\Http\Controllers\Manutenzioni;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ManutenzioneTipologia;
use App\Models\ManutenzioneChecklistDinamica;

class TipologiaController extends Controller
{
    public function index()
    {
        $tipologie = ManutenzioneTipologia::with('checklistDinamica')->get();
        return view('manutenzioni.tipologie.index', compact('tipologie'));
    }

    public function create()
    {
        return view('manutenzioni.tipologie.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'nome' => 'required|string|max:255',
            'descrizione' => 'nullable|string',
            'periodicita_mesi' => 'nullable|integer|min:1',
            'obbligatoria' => 'boolean',
            'con_checklist' => 'boolean',
            'documentabile' => 'boolean',
            'note' => 'nullable|string',
            'checklist.*.voce' => 'required_with:checklist|string',
            'checklist.*.obbligatoria' => 'required_with:checklist|boolean',
        ]);

        $tipologia = ManutenzioneTipologia::create($validated);

        if ($request->con_checklist && $request->has('checklist')) {
            ManutenzioneChecklistDinamica::create([
                'tipologia_id' => $tipologia->id,
                'contenuto' => json_encode($request->checklist),
            ]);
        }

        return redirect()->route('manutenzioni.tipologie.index')->with('success', 'Tipologia creata con successo');
    }

    public function edit($id)
    {
        $tipologia = ManutenzioneTipologia::with('checklistDinamica')->findOrFail($id);
        return view('manutenzioni.tipologie.edit', compact('tipologia'));
    }

    public function update(Request $request, $id)
    {
        $tipologia = ManutenzioneTipologia::findOrFail($id);

        $validated = $request->validate([
            'nome' => 'required|string|max:255',
            'descrizione' => 'nullable|string',
            'periodicita_mesi' => 'nullable|integer|min:1',
            'obbligatoria' => 'boolean',
            'con_checklist' => 'boolean',
            'documentabile' => 'boolean',
            'note' => 'nullable|string',
            'checklist.*.voce' => 'required_with:checklist|string',
            'checklist.*.obbligatoria' => 'required_with:checklist|boolean',
        ]);

        $tipologia->update($validated);

        if ($request->con_checklist) {
            ManutenzioneChecklistDinamica::updateOrCreate(
                ['tipologia_id' => $tipologia->id],
                ['contenuto' => json_encode($request->checklist)]
            );
        } else {
            // Se con_checklist disattivato, rimuovo eventuale checklist associata
            $tipologia->checklistDinamica()->delete();
        }

        return redirect()->route('manutenzioni.tipologie.index')->with('success', 'Tipologia aggiornata con successo');
    }

    public function destroy($id)
    {
        $tipologia = ManutenzioneTipologia::findOrFail($id);
        $tipologia->checklistDinamica()->delete();
        $tipologia->delete();

        return redirect()->route('manutenzioni.tipologie.index')->with('success', 'Tipologia eliminata con successo');
    }

    public function show($id)
    {
        return redirect()->route('manutenzioni.tipologie.edit', $id);
    }
}
