<?php

namespace App\Http\Controllers\Manutenzioni;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ManutenzioneChecklistDinamica;
use App\Models\ManutenzioneTipologia;

class ChecklistController extends Controller
{
    public function index()
    {
        $checklists = ManutenzioneChecklistDinamica::with('tipologia')->get();
        return view('manutenzioni.checklist.index', compact('checklists'));
    }

    public function create()
    {
        $tipologie = ManutenzioneTipologia::orderBy('nome')->get();
        return view('manutenzioni.checklist.create', compact('tipologie'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
			'nome' => 'required|string|max:255',
            'tipologia_id' => 'required|exists:manutenzioni_tipologie,id',
            'contenuto' => 'required|string', // non 'json'
        ]);
		
		$validated['contenuto'] = json_decode($validated['contenuto'], true); // decode manuale

        ManutenzioneChecklistDinamica::create($validated);

        return redirect()->route('manutenzioni.checklist.index')->with('success', 'Checklist creata con successo.');
    }

    public function edit($id)
    {
        $checklist = ManutenzioneChecklistDinamica::findOrFail($id);
        $tipologie = ManutenzioneTipologia::orderBy('nome')->get();

        return view('manutenzioni.checklist.edit', compact('checklist', 'tipologie'));
    }

    public function update(Request $request, $id)
    {
        $validated = $request->validate([
			'nome' => 'required|string|max:255',
            'tipologia_id' => 'required|exists:manutenzioni_tipologie,id',
            'contenuto' => 'required|string', // non 'json'
        ]);
		
		$validated['contenuto'] = json_decode($validated['contenuto'], true); // decode manuale
        $checklist = ManutenzioneChecklistDinamica::findOrFail($id);
        $checklist->update($validated);

        return redirect()->route('manutenzioni.checklist.index')->with('success', 'Checklist aggiornata con successo.');
    }

    public function destroy($id)
    {
        $checklist = ManutenzioneChecklistDinamica::findOrFail($id);
        $checklist->delete();

        return redirect()->route('manutenzioni.checklist.index')->with('success', 'Checklist eliminata.');
    }
	
	public function campiJson($id)
	{
		$checklist = \App\Models\ManutenzioneChecklistDinamica::findOrFail($id);
		return response()->json($checklist->contenuto ?? []);
	}

}
