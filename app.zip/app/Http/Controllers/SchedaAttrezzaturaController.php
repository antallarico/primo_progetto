<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Attrezzatura;

class SchedaAttrezzaturaController extends Controller
{
    public function create($attrezzatura_id)
    {
        $attrezzatura = Attrezzatura::with('tipologia')->findOrFail($attrezzatura_id);

        if (!$attrezzatura->tipologia || !$attrezzatura->tipologia->scheda_view) {
            return back()->with('error', 'Nessuna scheda associata alla tipologia.');
        }

        return view($attrezzatura->tipologia->scheda_view . '.create', compact('attrezzatura'));
    }

    public function edit($attrezzatura_id)
    {
        $attrezzatura = Attrezzatura::with(['tipologia'])->findOrFail($attrezzatura_id);
		//$attrezzatura = Attrezzatura::with(['tipologia', 'estintore'])->findOrFail($attrezzatura_id);
		if (!$attrezzatura->tipologia || !$attrezzatura->tipologia->scheda_view || !$attrezzatura->tipologia->scheda_tabella) {
        //if (!$attrezzatura->tipologia || !$attrezzatura->tipologia->scheda_view) {
            return back()->with('error', 'Nessuna scheda associata alla tipologia.');
        }
		
		$variabile = $attrezzatura->tipologia->scheda_tabella;
        $$variabile = $attrezzatura->{$variabile}; // es. $estintore = $attrezzatura->estintore;
        //$scheda = $attrezzatura->{$attrezzatura->tipologia->scheda_tabella};
		
		return view(
            $attrezzatura->tipologia->scheda_view . '.edit',
            compact('attrezzatura', $variabile) // es. ['attrezzatura' => ..., 'estintore' => ...]
        );
        //return view($attrezzatura->tipologia->scheda_view . '.edit', compact('attrezzatura', 'scheda'));
    }
}
