<?php
namespace App\Http\Controllers;

use App\Models\Attrezzatura;
use App\Models\AttrezzaturaGru;
use Illuminate\Http\Request;

class AttrezzaturaGruController extends Controller
{
    public function create($attrezzatura_id)
    {
        $attrezzatura = Attrezzatura::findOrFail($attrezzatura_id);
        return view('schede.attrezzature.gru.create', compact('attrezzatura'));
    }

    public function store(Request $request, $attrezzatura_id)
    {
        $request->validate([
            'portata_max_kg' => 'nullable|integer',
            'altezza_max_m' => 'nullable|integer',
            'data_installazione' => 'nullable|date',
			'manutenzione_periodica' => 'nullable|boolean',
            'note' => 'nullable|string',
        ]);
        $attrezzatura = Attrezzatura::findOrFail($attrezzatura_id);
        $data = $request->all();
        $data['attrezzatura_id'] = $attrezzatura->id;
        AttrezzaturaGru::create($data);
        return redirect()->route('attrezzature.index')->with('success', 'Scheda gru creata.');
    }

    public function edit($attrezzatura_id)
    {
        $attrezzatura = Attrezzatura::with('gru')->findOrFail($attrezzatura_id);
        return view('schede.attrezzature.gru.edit', [
            'attrezzatura' => $attrezzatura,
            'scheda'       => $attrezzatura->gru
        ]);
    }

    public function update(Request $request, $attrezzatura_id)
    {
        $request->validate([
            'portata_max_kg' => 'nullable|integer',
            'altezza_max_m' => 'nullable|integer',
            'data_installazione' => 'nullable|date',
			'manutenzione_periodica' => 'nullable|boolean',
            'note' => 'nullable|string',
        ]);
        $attrezzatura = Attrezzatura::findOrFail($attrezzatura_id);
        $scheda = $attrezzatura->gru;
        $scheda->update($request->all());
        return redirect()->route('attrezzature.index')->with('success', 'Scheda gru aggiornata.');
    }

    public function destroy($attrezzatura_id)
    {
        $attrezzatura = Attrezzatura::findOrFail($attrezzatura_id);
        if($attrezzatura->gru) {
            $attrezzatura->gru->delete();
        }
        return redirect()->route('attrezzature.index')->with('success', 'Scheda gru eliminata.');
    }
}
