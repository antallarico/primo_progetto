<?php

namespace App\Http\Controllers\Attrezzature;

use App\Http\Controllers\Controller;
use App\Models\Attrezzatura;
use App\Models\AttrezzaturaSchedaVoce;
use App\Models\ModelloDinamico;
use Illuminate\Http\Request;

class SchedaVoceController extends Controller
{
    // Mostra il form di compilazione per una determinata attrezzatura e modello
    public function create($attrezzatura_id, $modello_id)
	
    {
        $attrezzatura = Attrezzatura::findOrFail($attrezzatura_id);
        $modello = ModelloDinamico::where('id', $modello_id)
            ->where('modulo', 'Attrezzature')
            ->firstOrFail();
		
		$modelli = ModelloDinamico::where('modulo', 'Attrezzature')->get();
		$campi = $modello->contenuto; // JSON già castato come array, se il model ha il cast corretto

		$valoriPrecaricati = []; // nessun valore in fase di creazione
		$attrezzature = Attrezzatura::all();
        return view('attrezzature.schede_voci.create', compact('attrezzatura', 'modello', 'modelli', 'attrezzature', 'campi', 'valoriPrecaricati'));
    }
	
	public function edit($attrezzatura_id, $modello_id)
	{
		$attrezzatura = Attrezzatura::findOrFail($attrezzatura_id);

		$modello = ModelloDinamico::where('id', $modello_id)
			->where('modulo', 'Attrezzature')
			->firstOrFail();

		$voci = AttrezzaturaSchedaVoce::where('attrezzatura_id', $attrezzatura_id)
			->where('modello_id', $modello_id)
			->get();

		$valoriPrecaricati = $voci->map(fn($voce) => [
			'voce' => $voce->voce,
			'valore' => $voce->esito_voce,
		])->toArray();

		return view('attrezzature.schede_voci.edit', compact('attrezzatura', 'modello', 'valoriPrecaricati'));
	}

	

    // Salva la scheda compilata
	public function store(Request $request)
	{ //dd($request->all());
		$attrezzatura_id = $request->input('attrezzatura_id');
		$modello_id = $request->input('modello_id');

		$modello = ModelloDinamico::findOrFail($modello_id);
		$campi = $modello->contenuto;

		if (!is_array($campi)) {
			return back()->with('error', 'Errore nel modello dinamico.');
		}

		$voci = $request->input('voci', []);

		foreach ($voci as $voce) {
			$descrizione = $voce['descrizione'] ?? null;
			$valore = $voce['valore'] ?? null;

			if ($descrizione !== null) {
				AttrezzaturaSchedaVoce::create([
					'attrezzatura_id' => $attrezzatura_id,
					'modello_id' => $modello_id,
					'voce' => $descrizione,
					'esito_voce' => is_array($valore) ? json_encode($valore) : $valore,
					'note' => null,
				]);
			}
		}
		
		return redirect()->route('attrezzature.index')->with('success', 'Scheda creata con successo.');    
	}

	public function update(Request $request, $attrezzatura_id, $modello_id)
	{
		// Validazione di base
		$request->validate([
			'voci' => 'required|array',
			'voci.*.descrizione' => 'required|string',
			'voci.*.valore' => 'nullable|string',
		]);

		// Elimina le voci precedenti
		AttrezzaturaSchedaVoce::where('attrezzatura_id', $attrezzatura_id)
			->where('modello_id', $modello_id)
			->delete();

		// Salva le nuove voci
		foreach ($request->input('voci') as $voce) {
			AttrezzaturaSchedaVoce::create([
				'attrezzatura_id' => $attrezzatura_id,
				'modello_id' => $modello_id,
				'voce' => $voce['descrizione'],
				'esito_voce' => is_array($voce['valore']) ? json_encode($voce['valore']) : $voce['valore'],
				'note' => null,
			]);
		}
		
		return redirect()->route('attrezzature.index')->with('success', 'Scheda creata con successo.');
	}


}
