<?php

namespace App\Http\Controllers\Attrezzature;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\AttrezzaturaScheda;
use App\Models\AttrezzaturaTipologia;

class SchedaDinamicaController extends Controller
{
    public function index()
    {
        $schede = AttrezzaturaScheda::with('tipologia')
                    ->whereNotNull('contenuto')
                    ->get();

        return view('attrezzature.schede.index', compact('schede'));
    }

    public function create()
    {
        $tipologie = AttrezzaturaTipologia::orderBy('nome')->get();
        return view('attrezzature.schede.create', compact('tipologie'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'nome' => 'required|string|max:255',
            'tipologia_id' => 'nullable|exists:attrezzature_tipologie,id',
            'contenuto' => 'required|json',
        ]);

        AttrezzaturaScheda::create([
            'nome' => $request->input('nome'),
            'tipologia_id' => $request->input('tipologia_id'),
            'contenuto' => json_decode($request->input('contenuto'), true),
        ]);

        return redirect()->route('attrezzature.schede.index')->with('success', 'Scheda creata con successo.');
    }

    public function edit($id)
    {
        $scheda = AttrezzaturaScheda::findOrFail($id);
        $tipologie = AttrezzaturaTipologia::orderBy('nome')->get();
        return view('attrezzature.schede.edit', compact('scheda', 'tipologie'));
    }

    public function update(Request $request, $id)
    {
        $scheda = AttrezzaturaScheda::findOrFail($id);    

        $request->validate([
            'nome' => 'required|string|max:255',
            'tipologia_id' => 'nullable|exists:attrezzature_tipologie,id',
            'contenuto' => 'required|json',
        ]);

        $scheda->update([
            'nome' => $request->input('nome'),
            'tipologia_id' => $request->input('tipologia_id'),
            'contenuto' => json_decode($request->input('contenuto'), true),
        ]);

        return redirect()->route('attrezzature.schede.index')->with('success', 'Scheda aggiornata con successo.');
    }

    public function destroy(AttrezzaturaScheda $scheda)
    {
        $scheda->delete();
        return redirect()->route('attrezzature.schede.index')->with('success', 'Scheda eliminata con successo.');
    }

    // Endpoint per fornire i campi JSON via JS
    public function campi($id)
    {
        $scheda = AttrezzaturaScheda::findOrFail($id);
        return response()->json(json_decode($scheda->contenuto, true));
    }
}
