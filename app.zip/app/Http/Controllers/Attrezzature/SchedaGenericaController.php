<?php

namespace App\Http\Controllers\Attrezzature;

use App\Http\Controllers\Controller;
use App\Models\Attrezzatura;
use App\Models\AttrezzaturaScheda;
use Illuminate\Http\Request;

class SchedaGenericaController extends Controller
{
/*	
	public function edit($id)
{
    $attrezzatura = \App\Models\Attrezzatura::with('scheda', 'tipologia')->find($id);

    if (!$attrezzatura) {
        abort(500, "Attrezzatura ID {$id} non trovata.");
    }

    if (!$attrezzatura->tipologia) {
        abort(500, "Tipologia non trovata per attrezzatura ID {$id}.");
    }

    $slug = strtolower($attrezzatura->tipologia->nome);
    $fileJson = resource_path("config/schede_attrezzature/{$slug}.json");

    if (!file_exists($fileJson)) {
        abort(500, "File JSON non trovato: {$fileJson}");
    }

    return response()->json([
        'attrezzatura' => $attrezzatura,
        'slug' => $slug,
        'fileJson' => $fileJson,
        'fileExists' => file_exists($fileJson),
    ]);
}

	
*/
  
    public function edit($id)
    {
        $attrezzatura = Attrezzatura::with('scheda', 'tipologia')->findOrFail($id);

        $slug = strtolower($attrezzatura->tipologia->nome);
        $fileJson = resource_path("config/schede_attrezzature/{$slug}.json");

        if (!file_exists($fileJson)) {
            abort(404, "Configurazione per tipologia '{$slug}' non trovata");
        }

        $config = json_decode(file_get_contents($fileJson), true);
        $dati = $attrezzatura->scheda->dati ?? [];

        return view('schede_attrezzature.generica', compact('attrezzatura', 'config', 'dati'));
    }

    public function update(Request $request, $id)
    {
        $attrezzatura = Attrezzatura::findOrFail($id);
        $tipologiaSlug = strtolower($attrezzatura->tipologia->nome);
        $fileJson = resource_path("config/schede_attrezzature/{$tipologiaSlug}.json");

        if (!file_exists($fileJson)) {
            abort(404, "Configurazione per tipologia '{$tipologiaSlug}' non trovata");
        }

        $config = json_decode(file_get_contents($fileJson), true);
        $keys = array_keys($config['campi']);
        $datiInput = $request->only($keys);

        AttrezzaturaScheda::updateOrCreate(
            ['attrezzatura_id' => $attrezzatura->id],
            ['tipologia_id' => $attrezzatura->tipologia_id, 'dati' => $datiInput]
        );

        return back()->with('success', 'Scheda aggiornata con successo');
    }
}
