<?php

namespace App\Http\Controllers;

use App\Models\ModelloDinamico;
use Illuminate\Http\Request;

class ModelloDinamicoController extends Controller
{
    // Elenco dei modelli
    public function index()
    {
        $modelli = ModelloDinamico::orderBy('modulo')->get();
        return view('modelli_dinamici.index', compact('modelli'));
    }

    // Form di creazione
    public function create()
    {
        return view('modelli_dinamici.create');
    }

    // Salvataggio del nuovo modello
    public function store(Request $request)
    {
        $validated = $request->validate([
            'nome' => 'required|string|max:255',
            'modulo' => 'required|string|max:100',
            'tipologia_id' => 'nullable|integer',
            'contenuto' => 'required|json',
        ]);
		
		$validated['contenuto'] = json_decode($validated['contenuto'], true);
		
        ModelloDinamico::create($validated);
        return redirect()->route('modelli_dinamici.index')->with('success', 'Modello creato con successo.');
    }

    // Modifica
    public function edit(ModelloDinamico $modelloDinamico)
    {
        return view('modelli_dinamici.edit', compact('modelloDinamico'));
    }

    // Aggiorna
    public function update(Request $request, ModelloDinamico $modelloDinamico)
    {
        $validated = $request->validate([
            'nome' => 'required|string|max:255',
            'modulo' => 'required|string|max:100',
            'tipologia_id' => 'nullable|integer',
            'contenuto' => 'required|json',
        ]);
		
		$validated['contenuto'] = json_decode($validated['contenuto'], true);

        $modelloDinamico->update($validated);
        return redirect()->route('modelli_dinamici.index')->with('success', 'Modello aggiornato con successo.');
    }

    // Elimina
    public function destroy(ModelloDinamico $modelloDinamico)
    {
        $modelloDinamico->delete();
        return redirect()->route('modelli_dinamici.index')->with('success', 'Modello eliminato.');
    }
	// da dismettere?
	public function campiJson($id)
	{
		$modello = ModelloDinamico::findOrFail($id);
		return response()->json($modello->contenuto); // restituisce l’array json di campi
	}
	
	// app/Http/Controllers/ModelloDinamicoController.php
	public function showJson(\App\Models\ModelloDinamico $modello)
	{
		return response()->json([
			'id'     => $modello->id,
			'name'   => $modello->nome,
			'version'=> $modello->version,
			'schema' => $modello->schema_json ?? $modello->contenuto ?? [],
			'layout' => $modello->layout_json ?? null,
		]);
}


}
