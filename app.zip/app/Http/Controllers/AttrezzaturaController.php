<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Attrezzatura;
use App\Models\AttrezzaturaCategoria;
use App\Models\AttrezzaturaTipologia;
use App\Models\ModelloDinamico;

class AttrezzaturaController extends Controller
{
    public function index() 
    {
        $attrezzature = Attrezzatura::with(['categoria', 'attrezzaturaPadre', 'tipologia', 'estintore'])->orderBy('nome')->orderBy('id')->get();
		
		// Aggiungiamo i modelli dinamici per il modulo 'Attrezzature'
		$modelli = ModelloDinamico::where('modulo', 'Attrezzature')->get();
		
        return view('attrezzature.index', compact('attrezzature', 'modelli'));
    }

    public function create()
    {	
		$categorie = AttrezzaturaCategoria::orderBy('nome')->get();
		$padri = Attrezzatura::orderBy('nome')->get();
		$tipologie = AttrezzaturaTipologia::orderBy('nome')->get();
		return view('attrezzature.create', compact('categorie', 'padri', 'tipologie'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'nome' => 'required|string|max:255',
            'marca' => 'nullable|string|max:255',
            'modello' => 'nullable|string|max:255',
            'matricola' => 'nullable|string|max:255',
            'data_fabbricazione' => 'nullable|date',
            'ubicazione' => 'nullable|string|max:255',
            'stato' => 'required|string|in:in uso,fuori uso,dismessa',
            'note' => 'nullable|string',
            'categoria_id' => 'nullable|exists:attrezzature_categorie,id',
            'attrezzatura_padre_id' => 'nullable|exists:attrezzature,id',
            'tipo' => 'nullable|string|max:255',
            'dich_ce' => 'nullable|in:1,0',
			'tipologia_id' => 'nullable|exists:attrezzature_tipologie,id',
        ]);

        $data['dich_ce'] = match ($request->input('dich_ce')) {
            '1' => true,
            '0' => false,
            default => null,
        };

        Attrezzatura::create($data);
        return redirect()->route('attrezzature.index');
    }

    public function edit(Attrezzatura $attrezzatura)
    {
        $categorie = AttrezzaturaCategoria::orderBy('nome')->get();
		$padri = Attrezzatura::where('id', '!=', $attrezzatura->id)->orderBy('nome')->get();
		$tipologie = AttrezzaturaTipologia::orderBy('nome')->get();
		return view('attrezzature.edit', compact('attrezzatura', 'categorie', 'padri', 'tipologie'));
    }

    public function update(Request $request, Attrezzatura $attrezzatura)
    {
        $data = $request->validate([
            'nome' => 'required|string|max:255',
            'marca' => 'nullable|string|max:255',
            'modello' => 'nullable|string|max:255',
            'matricola' => 'nullable|string|max:255',
            'data_fabbricazione' => 'nullable|date',
            'ubicazione' => 'nullable|string|max:255',
            'stato' => 'required|string|in:in uso,fuori uso,dismessa',
            'note' => 'nullable|string',
            'categoria_id' => 'nullable|exists:attrezzature_categorie,id',
            'attrezzatura_padre_id' => 'nullable|exists:attrezzature,id',
            'tipo' => 'nullable|string|max:255',
            'dich_ce' => 'nullable|in:1,0',
			'tipologia_id' => 'nullable|exists:attrezzature_tipologie,id',
        ]);

        $data['dich_ce'] = match ($request->input('dich_ce')) {
            '1' => true,
            '0' => false,
            default => null,
        };

        $attrezzatura->update($data);
        return redirect()->route('attrezzature.index');
    }

    public function destroy(Attrezzatura $attrezzatura)
    {
        $attrezzatura->delete();
        return redirect()->route('attrezzature.index');
    }
	
}
