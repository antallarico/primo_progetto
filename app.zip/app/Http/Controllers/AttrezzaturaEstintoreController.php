<?php

namespace App\Http\Controllers;

use App\Models\Attrezzatura;
use App\Models\AttrezzaturaEstintore;
use Illuminate\Http\Request;

class AttrezzaturaEstintoreController extends Controller
{
	// Elenco schede estintori
	public function index()
	{
		$estintori = AttrezzaturaEstintore::with('attrezzatura')->orderByDesc('created_at')->get();
		return view('schede.attrezzature.estintore.index', compact('estintori'));
	}

    // Mostra la scheda estintore associata a una attrezzatura
    public function show($attrezzatura_id)
    {
        $attrezzatura = Attrezzatura::findOrFail($attrezzatura_id);
        $estintore = $attrezzatura->estintore;

        return view('schede.attrezzature.estintore.show', compact('attrezzatura', 'estintore'));
    }

    // Form per creare dati estintore per una attrezzatura
    public function create($attrezzatura_id)
    {
        $attrezzatura = Attrezzatura::findOrFail($attrezzatura_id);
        return view('schede.attrezzature.estintore.create', compact('attrezzatura'));
    }

    // Salva i dati inseriti
    public function store(Request $request, $attrezzatura_id)
    {
        $attrezzatura = Attrezzatura::findOrFail($attrezzatura_id);

        $data = $request->validate([
            'tipologia' => 'nullable|string|max:255',
            'capacita_kg' => 'nullable|integer',
            'mobile' => 'nullable|boolean',
            'data_collocazione' => 'nullable|date',
            'ubicazione_dettaglio' => 'nullable|string|max:255',
            'norma_riferimento' => 'nullable|string|max:255',
            'note' => 'nullable|string',
        ]);

        $data['attrezzatura_id'] = $attrezzatura->id;

        AttrezzaturaEstintore::create($data);

        return redirect()->route('schede.attrezzature.estintore.index')->with('success', 'Scheda estintore creata.');
    }

    // Form per modificare
    public function edit($attrezzatura_id)
    {
        $attrezzatura = Attrezzatura::findOrFail($attrezzatura_id);
        $estintore = $attrezzatura->estintore;

        return view('schede.attrezzature.estintore.edit', compact('attrezzatura', 'estintore'));
    }

    // Aggiorna i dati
    public function update(Request $request, $attrezzatura_id)
    {
        $attrezzatura = Attrezzatura::findOrFail($attrezzatura_id);
        $estintore = $attrezzatura->estintore;

        $data = $request->validate([
            'tipologia' => 'nullable|string|max:255',
            'capacita_kg' => 'nullable|integer',
            'mobile' => 'nullable|boolean',
            'data_collocazione' => 'nullable|date',
            'ubicazione_dettaglio' => 'nullable|string|max:255',
            'norma_riferimento' => 'nullable|string|max:255',
            'note' => 'nullable|string',
        ]);

        $estintore->update($data);

        return redirect()->route('attrezzature.index')->with('success', 'Scheda estintore aggiornata.');
    }

    // Eventuale eliminazione (opzionale)
    public function destroy($attrezzatura_id)
    {
        $attrezzatura = Attrezzatura::findOrFail($attrezzatura_id);
        $estintore = $attrezzatura->estintore;

        if ($estintore) {
            $estintore->delete();
        }

        return redirect()->route('attrezzature.index')->with('success', 'Scheda estintore rimossa.');
    }
}
