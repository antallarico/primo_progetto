<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ManutenzioneRegistroVoce extends Model
{
    use HasFactory;

    protected $table = 'manutenzioni_registro_voci';

    protected $fillable = [
        'registro_id',
        'modello_id',     // ✅ ora viene salvato correttamente
        'voce',
        'esito_voce',     // ✅ corregge 'esito'
        'note',
    ];

    public function registro()
    {
        return $this->belongsTo(ManutenzioneRegistro::class, 'registro_id');
    }

    public function modello()
    {
        return $this->belongsTo(ModelloDinamico::class, 'modello_id');
    }
}
