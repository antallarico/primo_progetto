<?php

namespace App\Models;

//use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;


class AttrezzaturaGru extends Model
{
    protected $table = 'attrezzature_gru';

    protected $fillable = [
        'attrezzatura_id',
        'portata_max_kg',
        'altezza_max_m',
        'data_installazione',
        'manutenzione_periodica',
        'note',
    ];

    public function attrezzatura(): BelongsTo
    {
        return $this->belongsTo(Attrezzatura::class, 'attrezzatura_id');
    }
}



