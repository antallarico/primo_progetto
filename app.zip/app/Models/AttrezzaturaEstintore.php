<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AttrezzaturaEstintore extends Model
{
    protected $table = 'attrezzature_estintori';

    protected $fillable = [
        'attrezzatura_id',
        'tipologia',
        'capacita_kg',
        'mobile',
        'data_collocazione',
        'ubicazione_dettaglio',
        'norma_riferimento',
        'note',
    ];

    public function attrezzatura()
    {
        return $this->belongsTo(Attrezzatura::class);
    }
}
