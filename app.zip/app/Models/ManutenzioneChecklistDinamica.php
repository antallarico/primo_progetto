<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ManutenzioneChecklistDinamica extends Model
{
    use HasFactory;

    protected $table = 'manutenzioni_checklist_dinamiche';

    protected $fillable = [
        'nome', 'tipologia_id', 'contenuto'
    ];

    protected $casts = [
        'contenuto' => 'array'
    ];

    public function tipologia()
    {
        return $this->belongsTo(ManutenzioneTipologia::class, 'tipologia_id');
    }
}
