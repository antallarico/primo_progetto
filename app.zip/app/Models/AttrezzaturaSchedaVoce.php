<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AttrezzaturaSchedaVoce extends Model
{
    protected $table = 'attrezzature_schede_voci';

    protected $fillable = [
        'attrezzatura_id',
        'modello_id',
        'voce',
        'esito_voce',
        'note',
    ];

    public function attrezzatura()
    {
        return $this->belongsTo(Attrezzatura::class);
    }

    public function modello()
    {
        return $this->belongsTo(ModelloDinamico::class, 'modello_id');
    }
}
