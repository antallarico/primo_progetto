<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ModelloDinamico extends Model
{
    protected $table = 'modelli_dinamici';

    protected $fillable = [
        'nome',
        'modulo',
        'tipologia_id',
        'contenuto',
    ];

    protected $casts = [
        'contenuto' => 'array',
    ];
}
