<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\AttrezzaturaCategoria;
use App\Models\AttrezzaturaEstintore;
use App\Models\AttrezzaturaTipologia;
use App\Models\AttrezzaturaGru;



class Attrezzatura extends Model
{
    use HasFactory;

    protected $table = 'attrezzature'; // <-- CORRETTO
    protected $fillable = [
        'nome',
        'marca',
        'modello',
        'matricola',
        'data_fabbricazione',
        'ubicazione',
        'stato',
        'note',
        'tipo',
        'attrezzatura_padre_id',
        'categoria_id',
		'dich_ce',
		'tipologia_id',
		'scheda_id',
    ];
	
	public function categoria()
    {
        return $this->belongsTo(AttrezzaturaCategoria::class, 'categoria_id');
    }
	
	public function attrezzaturaPadre()
	{
		return $this->belongsTo(Attrezzatura::class, 'attrezzatura_padre_id');
	}

	public function estintore()
	{
		return $this->hasOne(AttrezzaturaEstintore::class, 'attrezzatura_id');	
		//return $this->hasOne(AttrezzaturaEstintore::class);
	}
	
	public function tipologia()
	{
    return $this->belongsTo(AttrezzaturaTipologia::class, 'tipologia_id');
	}

	public function gru()
	{
		return $this->hasOne(AttrezzaturaGru::class);
	}
/*	
	public function scheda()
	{
		return $this->hasOne(AttrezzaturaScheda::class, 'attrezzatura_id');
	}
*/
	public function scheda()
	{
		return $this->belongsTo(AttrezzaturaScheda::class, 'scheda_id');
	}

}
